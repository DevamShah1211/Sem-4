from django.contrib import admin
from app1.models import Addgame
# Register your models here.

admin.site.register(Addgame)