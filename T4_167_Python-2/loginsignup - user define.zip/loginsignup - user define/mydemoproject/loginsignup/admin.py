from django.contrib import admin
# from loginsignup.models import AddGame1
from loginsignup.models import Student
# Register your models here.

# admin.site.register(AddGame1)
admin.site.register(Student)
